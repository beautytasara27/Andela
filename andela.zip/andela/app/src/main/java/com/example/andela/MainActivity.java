package com.example.andela;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button button1;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // getActionBar().setTitle("ALC 4 PHASE 1");
     //   getSupportActionBar().setTitle("ALC 4 PHASE 1");
        button1 = findViewById(R.id.myprofile);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_one = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent_one);
            }
        });
        button2 = findViewById(R.id.AboutALC);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_two = new Intent(MainActivity.this,ThirdActivity.class);
                startActivity(intent_two);

            }
        });

    }

}
